# GRA–Heisenberg Reasoning Architecture

A research-oriented repository describing a two-loop reasoning architecture
designed to stabilize reasoning under solution degeneracy via orthogonal constraints.

## Contents
- ARCHITECTURE.md — system architecture (EN/RU)
- THEORY.md — theoretical foundations (EN/RU)
- EXAMPLES.md — worked examples (EN/RU)
- IDEA_UNIVERSE.md — extended conceptual framework
- index.html — minimal simulator placeholder
